package com.utfpr.funcionariodepartamentolucas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuncionarioDepartamentoLucasApplicationTests {

	@Test
	void contextLoads() {
	}

}
