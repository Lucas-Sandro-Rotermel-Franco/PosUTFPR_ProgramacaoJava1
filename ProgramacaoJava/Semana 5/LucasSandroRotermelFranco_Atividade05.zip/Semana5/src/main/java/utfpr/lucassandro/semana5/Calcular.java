/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package utfpr.lucassandro.semana5;

/**
 *
 * @author lucassandro
 */
public interface Calcular {
    int calcular();
}
