/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exceptions;

/**
 *
 * @author lucassandro
 */
public class VelocException extends Exception {
    
    public VelocException() {
        super("A velocidade máxima está fora dos limites brasileiros.");
    }
}
